import sql from "mssql";
import { servError, noData, dataFound } from "../../res.mjs";
import { ISOString } from "../../helper_functions.mjs";

export const onlineSalesReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const onlineSalesReportItem = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const unitEconomicsReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Unit_Eco_VW @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const adminunitEconomicsReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Admin_Unit_Eco_VW @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const adminunitEconomicsReportsync = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Admin_Unit_Eco_SYNC @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const onlineSalesReportLOL = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const onlineSalesReportItemLOL = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Item_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}


export const SalesGraphCard = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Sales_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const onlinePurchaseReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Purchase_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const onlinePurchaseReportItem = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Purchase_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PurchaseGraphCard = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Purchase_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const SaleOrderReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const SaleOrderReportItem = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Item_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PurchaseOrderReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query("EXEC Reporting_Online_Purchase_Order_VW @Fromdate, @Todate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PurchaseOrderItemReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query("EXEC Reporting_Online_Purchase_Order_Item_VW @Fromdate, @Todate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }

}


export const StockValueGraph = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Stock_Value_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const StockValueReport = async (req, res) => {
    try {
        const Fromdate = req.query.Fromdate || req.query.FromDate;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .query("EXEC Stock_Value_CL_Rate @Fromdate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};


export const StaffBasedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Stock_Journal_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}


export const StaffBasedReportLOS = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Stock_Journal_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const costcenterList = async (req, res) => {
    try {
        const result = await new sql.Request()
            .execute("ERP_Cost_Center_vw");

        const recordset = result.recordset || [];

        if (recordset.length === 0) {
            return noData(res);
        }

        return dataFound(res, recordset);

    } catch (error) {
        console.error("Cost Center List Error:", error);
        return servError(error, res);
    }
};

export const OnlinePaymentReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Payment_VW @Fromdate, @Todate`);

        const [Summary, IndirectExpense, DirectExpense] = result.recordsets || [];

        if (!Summary || Summary.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Summary,
            IndirectExpense,
            DirectExpense
        });

    } catch (error) {
        servError(error, res);
    }
};

export const costingReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Payment_Costing_VW @Fromdate, @Todate`);

        const [ItemSummary, Accountgroup] = result.recordsets || [];

        if (!ItemSummary || ItemSummary.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            ItemSummary,
            Accountgroup
        });

    } catch (error) {
        servError(error, res);

    }

};

export const DebtorsCreditors = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Debtors_Creditors_VW @Fromdate, @Todate`);

        const [Data1, Creditors, Debtors] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Creditors, Debtors
        });

    } catch (error) {
        servError(error, res);
    }
};

export const StaffBasedCount = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Created_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const DayAbstractReport = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Day_Abstract_Report @Predate, @Fromdate, @Todate`);

        const [Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10
        });

    } catch (error) {
        servError(error, res);
    }
};

export const DayStockAbstractReport = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Day_Stock_Abstract_Report @Predate, @Fromdate, @Todate`);

        const [Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9
        });

    } catch (error) {
        servError(error, res);
    }
};

export const CashBoxReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Cash_List_VW @Fromdate, @Todate`);

        const [OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls
        });

    } catch (error) {
        servError(error, res);
    }
}

export const PendingSaleOrderReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Pending_LOL_VW  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PendingSaleOrderReportItem = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Pending_Item_LOL_VW  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const GodownInstockSummary = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Current_Stock_Summarry_Report @Predate, @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const StockInOutProcess = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC SP_Godown_Stock_Movement_Report  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const BankBoxReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Bank_List_VW @Fromdate, @Todate`);

        const [OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls
        });

    } catch (error) {
        servError(error, res);
    }
}

export const CashListDetailedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Cash_List_VW_Detailed @Fromdate, @Todate`);

        const [OB, Data, Group] = result.recordsets || [];

        if (!Data || Data.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data, Group
        });

    } catch (error) {
        servError(error, res);
    }
}

export const BankListDetailedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Bank_List_VW_Detailed @Fromdate, @Todate`);

        const [OB, Data, Group] = result.recordsets || [];

        if (!Data || Data.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data, Group
        });

    } catch (error) {
        servError(error, res);
    }
}

export const RecievableReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Transaction_Recivables_Reort_VW @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PayableReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Transaction_Payables_Reort_VW @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const SalesDeliveryCummulativeReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        const godown_id = req.query.GodownId || req.query.Godown_Id || req.query.godownId || req.query.godown_Id || null;

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .input("Godown_Id", godown_id)
            .query(`EXEC SalesDeliveryCummulativeReport @Fromdate, @Todate, @Godown_Id`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const SalesDeliveryDaywiseReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        const godown_id = req.query.GodownId || req.query.Godown_Id || req.query.godownId || req.query.godown_Id || null;

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .input("Godown_Id", godown_id)
            .query(`EXEC SalesDeliveryDatewiseReport @Fromdate, @Todate, @Godown_Id`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};