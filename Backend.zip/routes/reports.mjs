import express from 'express';
import stockAndPurchase from '../controller/Reports/stockAndPurchase.mjs';
import storageStockReport from '../controller/Reports/storageStockReport.mjs';
import expences from '../controller/Masters/expences.mjs';
import {
    onlineSalesReport, onlineSalesReportItem, unitEconomicsReport, onlineSalesReportLOL, onlineSalesReportItemLOL, SalesGraphCard, onlinePurchaseReport,
    onlinePurchaseReportItem, PurchaseGraphCard, SaleOrderReport, SaleOrderReportItem, PurchaseOrderReport, PurchaseOrderItemReport,
    StockValueGraph, StockValueReport, StaffBasedReport, costcenterList, StaffBasedReportLOS,
    OnlinePaymentReport, costingReport, DebtorsCreditors, StaffBasedCount, DayAbstractReport, DayStockAbstractReport,
    CashBoxReport, PendingSaleOrderReport, PendingSaleOrderReportItem,
    adminunitEconomicsReport,
    adminunitEconomicsReportsync,
    GodownInstockSummary,
    StockInOutProcess,
    BankBoxReport,
    CashListDetailedReport,
    BankListDetailedReport,
    RecievableReport,
    PayableReport,
    SalesDeliveryCummulativeReport
} from '../controller/Reports/externalAPI.mjs';
import receiptReport from '../controller/Reports/receiptReport.mjs';
import {
    MenuSettings, executeSP, saveReportSettings, getReportList, getReportEditData, updateReportSettings, getReportsByParent, executeReportByTemplate, deleteReport
} from '../controller/Reports/reportsettings.mjs';

const ReportRouter = express.Router();

// stock & sales reports
ReportRouter.get('/salesReport/ledger', stockAndPurchase.salesReport);
ReportRouter.get('/salesReport/products', stockAndPurchase.porductBasedSalesResult);
ReportRouter.get('/salesReport/ledger/itemDetails', stockAndPurchase.salesItemDetails);

// storage stock mobile reports
ReportRouter.get('/storageStock/itemWiseMobile', storageStockReport.getStorageStockItemWiseMobile);
ReportRouter.get('/storageStock/godownWiseMobile', storageStockReport.getStorageStockGodownWiseMobile);
ReportRouter.get('/storageStock/godownitemWise', storageStockReport.getStorageStockGodownitemWise);
// expenses reports
ReportRouter.get('/itemexpenseReport', expences.itemsTransactionExpandable);
ReportRouter.get('/godownexpenseReport', expences.godownTransactionExpandable);

// external APIs
ReportRouter.get('/externalAPI/onlineSalesReport', onlineSalesReport);
ReportRouter.get('/externalAPI/onlineSalesReportItem', onlineSalesReportItem);
ReportRouter.get('/externalAPI/unitEconomicsReport', unitEconomicsReport);
ReportRouter.get('/externalAPI/adminunitEconomics', adminunitEconomicsReport);
ReportRouter.get('/externalAPI/adminunitEconomicsSync', adminunitEconomicsReportsync);


ReportRouter.get('/externalAPI/onlineSalesReportLOL', onlineSalesReportLOL);
ReportRouter.get('/externalAPI/onlineSalesReportItemLOL', onlineSalesReportItemLOL);
ReportRouter.get('/externalAPI/SalesGraph', SalesGraphCard);
ReportRouter.get('/externalAPI/onlinePurchaseReport', onlinePurchaseReport);
ReportRouter.get('/externalAPI/onlinePurchaseReportItem', onlinePurchaseReportItem);
ReportRouter.get('/externalAPI/PurchaseGraph', PurchaseGraphCard);
ReportRouter.get('/externalAPI/SaleOrderReport', SaleOrderReport);
ReportRouter.get('/externalAPI/SaleOrderReportItem', SaleOrderReportItem);
ReportRouter.get('/externalAPI/PurchaseOrderReport', PurchaseOrderReport);
ReportRouter.get('/externalAPI/PurchaseOrderReportItem', PurchaseOrderItemReport);
ReportRouter.get('/externalAPI/StockValueGraph', StockValueGraph);
ReportRouter.get('/externalAPI/expenses', OnlinePaymentReport);
ReportRouter.get('/externalAPI/costing', costingReport);
ReportRouter.get('/externalAPI/stockValue', StockValueReport);
ReportRouter.get('/externalAPI/staffbased', StaffBasedReport);
ReportRouter.get('/externalAPI/debtorsCreditors', DebtorsCreditors);
ReportRouter.get('/externalAPI/staffBasedCount', StaffBasedCount);
ReportRouter.get('/externalAPI/costCenter', costcenterList);
ReportRouter.get('/externalAPI/staffbased', StaffBasedReportLOS);
ReportRouter.get('/externalAPI/dayAbstract', DayAbstractReport);
ReportRouter.get('/externalAPI/dayStockAbstract', DayStockAbstractReport);
ReportRouter.get('/externalAPI/cashbox', CashBoxReport);
ReportRouter.get('/externalAPI/Bankbox', BankBoxReport);
ReportRouter.get('/externalAPI/pendingSaleOrder', PendingSaleOrderReport);
ReportRouter.get('/externalAPI/pendingSaleOrderItem', PendingSaleOrderReportItem);
ReportRouter.get('/externalAPI/godownSummaryInstock', GodownInstockSummary);
ReportRouter.get('/externalAPI/cashListDetailed', CashListDetailedReport);
ReportRouter.get('/externalAPI/bankListDetailed', BankListDetailedReport);
ReportRouter.get('/externalAPI/stockinoutprocess', StockInOutProcess);
ReportRouter.get('/receipt/chequeTransaction', receiptReport.getChequeTransaction);
ReportRouter.get('/receipt/chequeAccounts', receiptReport.getChequeAccounts);
ReportRouter.get('/receipt/chequeCreditAccounts', receiptReport.getChequeCreditAccounts);
ReportRouter.get('/receipt/chequeVoucherTypes', receiptReport.getChequeVoucherTypes);
ReportRouter.get('/externalAPI/recievable', RecievableReport);
ReportRouter.get('/externalAPI/payable', PayableReport);
ReportRouter.get('/externalAPI/salesDeliveryCummulative', SalesDeliveryCummulativeReport);

// settings reports
ReportRouter.get('/settings/MenuSettings', MenuSettings);
ReportRouter.post('/settings/executeSP', executeSP);
ReportRouter.post('/settings/saveReport', saveReportSettings);
ReportRouter.get('/settings/reportList', getReportList);
ReportRouter.get('/settings/editreport', getReportEditData);
ReportRouter.put('/settings/updatereport', updateReportSettings);
ReportRouter.get('/settings/byParent', getReportsByParent);
ReportRouter.get('/settings/getreport', executeReportByTemplate);
ReportRouter.delete('/settings/deleteReport/:reportId', deleteReport);

// storage stock value reports
ReportRouter.get('/storageStock/stockvalueitem', storageStockReport.getStorageStockValueItemWise);
ReportRouter.get('/storageStock/stockvaluegodown', storageStockReport.getStorageStockValueGodownWise);

export default ReportRouter;