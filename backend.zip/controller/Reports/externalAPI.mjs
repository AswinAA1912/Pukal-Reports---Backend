import sql from "mssql";
import { servError, noData, dataFound, invalidInput } from "../../res.mjs";
import { ISOString } from "../../helper_functions.mjs";

export const onlineSalesReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const onlineSalesReportItem = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const unitEconomicsReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Unit_Eco_VW @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const adminunitEconomicsReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Admin_Unit_Eco_VW @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const adminunitEconomicsReportsync = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Admin_Unit_Eco_SYNC @Fromdate, @Todate`);

        const [rows, meta] = result.recordsets || [];

        if (!rows || rows.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            rows,
            lastStockValueDate: meta?.[0] ?? null
        });

    } catch (error) {
        servError(error, res);
    }
};

export const onlineSalesReportLOL = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const onlineSalesReportItemLOL = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Item_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}


export const SalesGraphCard = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Sales_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const onlinePurchaseReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Purchase_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const onlinePurchaseReportItem = async (req, res) => {
    try {
        const rawPoId =
            req.query.Po_Id ??
            req.query.po_id ??
            req.query.PoId ??
            req.query.poid ??
            req.query.Order_Id ??
            req.query.order_id ??
            req.body?.Po_Id ??
            req.body?.po_id ??
            req.body?.PoId ??
            req.body?.poid ??
            req.body?.Order_Id ??
            req.body?.order_id;

        const cleanPoId =
            rawPoId !== undefined && rawPoId !== null
                ? String(rawPoId).trim().replace(/^["']+|["']+$/g, "").trim()
                : "";

        if (cleanPoId && !isNaN(Number(cleanPoId))) {
            const request = new sql.Request();
            request.input("Po_Id", sql.BigInt, cleanPoId);

            const result = await request.query(
                `EXEC Reporting_Online_Purchase_Item_VW_By_Order_Id @Po_Id`
            );

            const recordset = result.recordset ?? [];
            if (!recordset.length) return noData(res);

            return dataFound(res, recordset);
        }

        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Purchase_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PurchaseGraphCard = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Purchase_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const SaleOrderReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const SaleOrderReportItem = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Item_LOL_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PurchaseOrderReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query("EXEC Reporting_Online_Purchase_Order_VW @Fromdate, @Todate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PurchaseOrderItemReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query("EXEC Reporting_Online_Purchase_Order_Item_VW @Fromdate, @Todate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }

}


export const StockValueGraph = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Dashboard_Stock_Value_VW @Fromdate, @Todate`);

        const [DayWise, WeekWiseData, DayWiseTonnage, WeekWiseTonnage] = result.recordsets || [];

        if (!DayWise || DayWise.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            DayWise,
            WeekWiseData,
            DayWiseTonnage,
            WeekWiseTonnage
        });

    } catch (error) {
        servError(error, res);
    }
};


export const StockValueReport = async (req, res) => {
    try {
        const Fromdate = req.query.Fromdate || req.query.FromDate;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .query("EXEC Stock_Value_CL_Rate @Fromdate")

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};


export const StaffBasedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Stock_Journal_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}


export const StaffBasedReportLOS = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Stock_Journal_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const costcenterList = async (req, res) => {
    try {
        const result = await new sql.Request()
            .execute("ERP_Cost_Center_vw");

        const recordset = result.recordset || [];

        if (recordset.length === 0) {
            return noData(res);
        }

        return dataFound(res, recordset);

    } catch (error) {
        console.error("Cost Center List Error:", error);
        return servError(error, res);
    }
};

export const OnlinePaymentReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Payment_VW @Fromdate, @Todate`);

        const [Summary, IndirectExpense, DirectExpense] = result.recordsets || [];

        if (!Summary || Summary.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Summary,
            IndirectExpense,
            DirectExpense
        });

    } catch (error) {
        servError(error, res);
    }
};

export const costingReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Payment_Costing_VW @Fromdate, @Todate`);

        const [ItemSummary, Accountgroup] = result.recordsets || [];

        if (!ItemSummary || ItemSummary.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            ItemSummary,
            Accountgroup
        });

    } catch (error) {
        servError(error, res);

    }

};

export const DebtorsCreditors = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Debtors_Creditors_VW @Fromdate, @Todate`);

        const [Data1, Creditors, Debtors] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Creditors, Debtors
        });

    } catch (error) {
        servError(error, res);
    }
};

export const StaffBasedCount = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Created_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const DayAbstractReport = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Day_Abstract_Report @Predate, @Fromdate, @Todate`);

        const [Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10
        });

    } catch (error) {
        servError(error, res);
    }
};

export const DayStockAbstractReport = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Day_Stock_Abstract_Report @Predate, @Fromdate, @Todate`);

        const [Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9
        });

    } catch (error) {
        servError(error, res);
    }
};

export const CashBoxReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Cash_List_VW @Fromdate, @Todate`);

        const [OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls
        });

    } catch (error) {
        servError(error, res);
    }
}

export const PendingSaleOrderReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Pending_LOL_VW  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const PendingSaleOrderReportItem = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Sales_Order_Pending_Item_LOL_VW  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const GodownInstockSummary = async (req, res) => {
    try {
        const { Predate, Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        let preDate;
        if (Predate) {
            preDate = ISOString(Predate);
        } else {
            const d = new Date(fromDate);
            d.setDate(d.getDate() - 1);
            preDate = ISOString(d);
        }

        const result = await new sql.Request()
            .input("Predate", preDate)
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Current_Stock_Summarry_Report @Predate, @Fromdate, @Todate`);

        const [Data, OB] = result.recordsets || [];

        if (!Data || Data.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data, OB,
        });
    } catch (error) {
        servError(error, res);
    }
};

export const StockInOutProcess = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC SP_Godown_Stock_Movement_Report  @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const BankBoxReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Bank_List_VW @Fromdate, @Todate`);

        const [OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data1, Cash, Bank, LedgerGrp, DEX, IDEX, RecPay, Jnl, Cls
        });

    } catch (error) {
        servError(error, res);
    }
}

export const CashListDetailedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Cash_List_VW_Detailed @Fromdate, @Todate`);

        const [OB, Data, Group] = result.recordsets || [];

        if (!Data || Data.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data, Group
        });

    } catch (error) {
        servError(error, res);
    }
}

export const BankListDetailedReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Bank_List_VW_Detailed @Fromdate, @Todate`);

        const [OB, Data, Group] = result.recordsets || [];

        if (!Data || Data.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            OB, Data, Group
        });

    } catch (error) {
        servError(error, res);
    }
}

export const RecievableReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Transaction_Recivables_Reort_VW @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PayableReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Transaction_Payables_Reort_VW @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const SalesDeliveryCummulativeReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        const godown_id = req.query.GodownId || req.query.Godown_Id || req.query.godownId || req.query.godown_Id || null;

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .input("Godown_Id", godown_id)
            .query(`EXEC SalesDeliveryCummulativeReport @Fromdate, @Todate, @Godown_Id`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const SalesDeliveryDaywiseReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();
        const godown_id = req.query.GodownId || req.query.Godown_Id || req.query.godownId || req.query.godown_Id || null;

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .input("Godown_Id", godown_id)
            .query(`EXEC SalesDeliveryDatewiseReport @Fromdate, @Todate, @Godown_Id`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const OverallStaffBasedCategorywiseReport = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        if (fromDate > toDate) {
            return noData(res);
        }

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC SP_Get_EmployeeReport_By_CostCategory_AllModules @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
}

export const getEmployeeReportGroupEmployees = async (req, res) => {
    try {
        const { Fromdate, Todate, Overall_GroupName, Group_Name, Voucher_Type } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("FromDate", sql.Date, fromDate)
            .input("ToDate", sql.Date, toDate)
            .input("Overall_GroupName", sql.NVarChar(255), Overall_GroupName || null)
            .input("Group_Name", sql.NVarChar(255), Group_Name || null)
            .input("Voucher_Type", sql.NVarChar(255), Voucher_Type || null)
            .execute("SP_Get_EmployeeReport_GroupEmployees");

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const getEmployeeReportEmployeeInvoices = async (req, res) => {
    try {
        const { Fromdate, Todate, Overall_GroupName, Group_Name, Voucher_Type, Voucher_Type_Id, VoucherId, Emp_Id, Emp_Id_Is_Unassigned } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const isUnassigned = Emp_Id_Is_Unassigned === 'true' || Emp_Id_Is_Unassigned === '1' ? 1 : 0;

        let voucherTypeId = null;
        const rawVoucher = Voucher_Type_Id || VoucherId || Voucher_Type;
        if (rawVoucher !== undefined && rawVoucher !== null && rawVoucher !== '') {
            if (!isNaN(Number(rawVoucher))) {
                voucherTypeId = Number(rawVoucher);
            } else {
                // If passed as string name, resolve ID from tbl_Voucher_Type
                const vtLookup = await new sql.Request()
                    .input("voucherName", sql.NVarChar(255), String(rawVoucher).trim())
                    .query(`SELECT TOP 1 Vocher_Type_Id FROM tbl_Voucher_Type WHERE Voucher_Type = @voucherName`);
                if (vtLookup.recordset && vtLookup.recordset.length > 0) {
                    voucherTypeId = Number(vtLookup.recordset[0].Vocher_Type_Id);
                }
            }
        }

        const result = await new sql.Request()
            .input("FromDate", sql.Date, fromDate)
            .input("ToDate", sql.Date, toDate)
            .input("Overall_GroupName", sql.NVarChar(255), Overall_GroupName || null)
            .input("Group_Name", sql.NVarChar(255), Group_Name || null)
            .input("Voucher_Type", sql.BigInt, voucherTypeId || null)
            .input("Emp_Id", sql.Int, Emp_Id ? Number(Emp_Id) : null)
            .input("Emp_Id_Is_Unassigned", sql.Bit, isUnassigned)
            .execute("SP_Get_EmployeeReport_EmployeeInvoices");

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const RateMasterAdmin = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Rate_Master_List_Admin  @Todate`);

        const [Data1, Data2] = result.recordsets || [];

        if (!Data1 || Data1.length === 0) {
            return noData(res);
        }

        dataFound(res, {
            Data1, Data2
        });

    } catch (error) {
        servError(error, res);
    }
}

export const invoicewithitems = async (req, res) => {
    try {
        const { Fromdate, Todate, Overall_GroupName, Group_Name, Voucher_Type, Voucher_Type_Id, VoucherId, Emp_Id, Emp_Id_Is_Unassigned } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const isUnassigned = Emp_Id_Is_Unassigned === 'true' || Emp_Id_Is_Unassigned === '1' ? 1 : 0;

        let voucherTypeId = null;
        const rawVoucher = Voucher_Type_Id || VoucherId || Voucher_Type;
        if (rawVoucher !== undefined && rawVoucher !== null && rawVoucher !== '') {
            if (!isNaN(Number(rawVoucher))) {
                voucherTypeId = Number(rawVoucher);
            } else {
                // If passed as string name, resolve ID from tbl_Voucher_Type
                const vtLookup = await new sql.Request()
                    .input("voucherName", sql.NVarChar(255), String(rawVoucher).trim())
                    .query(`SELECT TOP 1 Vocher_Type_Id FROM tbl_Voucher_Type WHERE Voucher_Type = @voucherName`);
                if (vtLookup.recordset && vtLookup.recordset.length > 0) {
                    voucherTypeId = Number(vtLookup.recordset[0].Vocher_Type_Id);
                }
            }
        }

        const result = await new sql.Request()
            .input("FromDate", sql.Date, fromDate)
            .input("ToDate", sql.Date, toDate)
            .input("Overall_GroupName", sql.NVarChar(255), Overall_GroupName || null)
            .input("Group_Name", sql.NVarChar(255), Group_Name || null)
            .input("Voucher_Type", sql.BigInt, voucherTypeId || null)
            .input("Emp_Id", sql.Int, Emp_Id ? Number(Emp_Id) : null)
            .input("Emp_Id_Is_Unassigned", sql.Bit, isUnassigned)
            .execute("SP_Get_EmployeeReport_EmployeeInvoices_with_ITEM");

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const reportingDetailedList = async (req, res) => {
    try {
        const rawRefId =
            req.query.Ref_Id ??
            req.query.Trans_Id ??
            req.query.ref_id ??
            req.query.trans_id ??
            req.body?.Ref_Id ??
            req.body?.Trans_Id ??
            req.body?.ref_id ??
            req.body?.trans_id;

        const rawTransType =
            req.query.Trans_Type ??
            req.query.trans_type ??
            req.body?.Trans_Type ??
            req.body?.trans_type;

        const cleanRefId =
            rawRefId !== undefined && rawRefId !== null
                ? String(rawRefId).trim().replace(/^["']+|["']+$/g, "").trim()
                : "";

        if (!cleanRefId || isNaN(Number(cleanRefId))) {
            return invalidInput(res, "Ref_Id is required and must be a valid number");
        }

        if (!rawTransType || typeof rawTransType !== "string" || !rawTransType.trim()) {
            return invalidInput(res, "Trans_Type is required");
        }

        const Trans_Id = Number(cleanRefId);
        const Trans_Type = String(rawTransType).trim().replace(/^["']+|["']+$/g, "").trim();

        const request = new sql.Request();
        request.input("Trans_Id", sql.BigInt, Trans_Id);
        request.input("Trans_Type", sql.VarChar(50), Trans_Type);

        const result = await request.execute("Reporting_Detailed_List_VW");

        const datasets = result.recordsets || [];
        const totalRows = datasets.reduce((sum, ds) => sum + (Array.isArray(ds) ? ds.length : 0), 0);

        if (datasets.length === 0 || totalRows === 0) {
            return noData(res, "No transaction details found for the given Ref_Id and Trans_Type");
        }

        const [Masters = [], Items = [], CostCenter = [], Expenses = []] = datasets;

        return dataFound(res, {
            Masters,
            Items,
            CostCenter,
            Expenses
        }, "Data Found");
    } catch (error) {
        servError(error, res);
    }
};

export const godownStockBadge = async (req, res) => {
    try {
        const rawFromDate =
            req.query.Fromdate ??
            req.query.FromDate ??
            req.query.fromDate ??
            req.body?.Fromdate ??
            req.body?.FromDate ??
            req.body?.fromDate;

        const rawToDate =
            req.query.Todate ??
            req.query.ToDate ??
            req.query.toDate ??
            req.body?.Todate ??
            req.body?.ToDate ??
            req.body?.toDate;

        const rawGodownId =
            req.query.godownId ??
            req.query.Godown_Id ??
            req.query.godown_id ??
            req.query.GodownId ??
            req.body?.godownId ??
            req.body?.Godown_Id ??
            req.body?.godown_id;

        const rawProductId =
            req.query.productId ??
            req.query.Item_Id ??
            req.query.itemId ??
            req.query.item_id ??
            req.query.ProductId ??
            req.query.product_id ??
            req.body?.productId ??
            req.body?.Item_Id ??
            req.body?.itemId;

        const normalizeDate = (val) => {
            if (!val) return ISOString();
            if (typeof val === "string") {
                const trimmed = val.trim();
                const match = trimmed.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
                if (match) {
                    const [, y, m, d] = match;
                    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
                }
            }
            return ISOString(val);
        };

        const fromDate = normalizeDate(rawFromDate);
        const toDate = normalizeDate(rawToDate);

        const cleanGodownId =
            rawGodownId !== undefined && rawGodownId !== null
                ? String(rawGodownId).trim()
                : "";

        const cleanProductId =
            rawProductId !== undefined && rawProductId !== null
                ? String(rawProductId).trim()
                : "";

        if (!cleanGodownId || isNaN(Number(cleanGodownId))) {
            return invalidInput(res, "godownId is required and must be a valid number");
        }

        if (!cleanProductId || isNaN(Number(cleanProductId))) {
            return invalidInput(res, "productId is required and must be a valid number");
        }

        const godownId = Number(cleanGodownId);
        const productId = Number(cleanProductId);

        const request = new sql.Request();
        request.input("Fromdate", sql.VarChar(50), fromDate);
        request.input("Todate", sql.VarChar(50), toDate);
        request.input("Godown_Id", sql.Int, godownId);
        request.input("Item_Id", sql.BigInt, productId);

        const result = await request.execute("Godown_Stock_Batch_IN_OUT_Process_Item_wise");

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        return dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const ItemwiseStockBadge = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        if (fromDate > toDate) {
            return noData(res);
        }

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Batch_Rpt_Stock_Process @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const TransactionBatchStockReportByProId = async (req, res) => {
    try {
        const rawFromDate =
            req.query.Fromdate ??
            req.query.FromDate ??
            req.query.fromDate ??
            req.body?.Fromdate ??
            req.body?.FromDate ??
            req.body?.fromDate;

        const rawToDate =
            req.query.Todate ??
            req.query.ToDate ??
            req.query.toDate ??
            req.body?.Todate ??
            req.body?.ToDate ??
            req.body?.toDate;

        const rawProductId =
            req.query.Product_Id ??
            req.query.productId ??
            req.query.ProductId ??
            req.query.product_id ??
            req.query.Item_Id ??
            req.query.itemId ??
            req.query.item_id ??
            req.body?.Product_Id ??
            req.body?.productId ??
            req.body?.ProductId ??
            req.body?.product_id ??
            req.body?.Item_Id ??
            req.body?.itemId ??
            req.body?.item_id;

        const rawBatch =
            req.query.Batch ??
            req.query.batch ??
            req.query.Batch_No ??
            req.query.batch_no ??
            req.body?.Batch ??
            req.body?.batch ??
            req.body?.Batch_No ??
            req.body?.batch_no;

        const normalizeDate = (val) => {
            if (!val) return ISOString();
            if (typeof val === "string") {
                const trimmed = val.trim();
                const match = trimmed.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
                if (match) {
                    const [, y, m, d] = match;
                    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
                }
            }
            return ISOString(val);
        };

        const fromDate = normalizeDate(rawFromDate);
        const toDate = normalizeDate(rawToDate);

        if (fromDate > toDate) {
            return noData(res);
        }

        const cleanProductId =
            rawProductId !== undefined && rawProductId !== null
                ? String(rawProductId).trim().replace(/^['"]+|['"]+$/g, "").trim()
                : "";

        if (!cleanProductId || isNaN(Number(cleanProductId))) {
            return noData(res);
        }

        const productId = Number(cleanProductId);

        // Sanitize batch: strip single/double quotes, URL-encoded quotes, and whitespace
        let cleanBatch =
            rawBatch !== undefined && rawBatch !== null
                ? String(rawBatch)
                    .trim()
                    .replace(/^['"]+|['"]+$/g, "")
                    .replace(/^['"]+|['"]+$/g, "")
                    .trim()
                : "Primary Batch";

        if (!cleanBatch) {
            cleanBatch = "Primary Batch";
        }

        // Handle cases where users enter 'Primary_Batch' or similar with underscores
        if (cleanBatch.replace(/_/g, " ").toLowerCase() === "primary batch") {
            cleanBatch = "Primary Batch";
        }

        const request = new sql.Request();
        request.input("Fromdate", sql.NVarChar(200), fromDate);
        request.input("Todate", sql.NVarChar(200), toDate);
        request.input("Product_Id", sql.Int, productId);
        request.input("Batch", sql.NVarChar(100), cleanBatch);

        let result = await request.query(
            `EXEC Transaction_Batch_Stock_Report_vw_By_Pro_Id @Fromdate, @Todate, @Product_Id, @Batch`
        );

        let recordset = result.recordset ?? [];

        // If no records found and batch has underscores/spaces/plus, try fallback alternative formatting
        if (!recordset.length && (cleanBatch.includes("_") || cleanBatch.includes("+"))) {
            const alternativeBatch = cleanBatch.replace(/[_\+]/g, " ").trim();
            const retryRequest = new sql.Request();
            retryRequest.input("Fromdate", sql.NVarChar(200), fromDate);
            retryRequest.input("Todate", sql.NVarChar(200), toDate);
            retryRequest.input("Product_Id", sql.Int, productId);
            retryRequest.input("Batch", sql.NVarChar(100), alternativeBatch);

            const retryResult = await retryRequest.query(
                `EXEC Transaction_Batch_Stock_Report_vw_By_Pro_Id @Fromdate, @Todate, @Product_Id, @Batch`
            );
            recordset = retryResult.recordset ?? [];
        }

        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const TransactionBatchStockReportByProIdandGodownId = async (req, res) => {
    try {
        const rawFromDate =
            req.query.Fromdate ??
            req.query.FromDate ??
            req.query.fromDate ??
            req.body?.Fromdate ??
            req.body?.FromDate ??
            req.body?.fromDate;

        const rawToDate =
            req.query.Todate ??
            req.query.ToDate ??
            req.query.toDate ??
            req.body?.Todate ??
            req.body?.ToDate ??
            req.body?.toDate;

        const rawProductId =
            req.query.Product_Id ??
            req.query.productId ??
            req.query.ProductId ??
            req.query.product_id ??
            req.query.Item_Id ??
            req.query.itemId ??
            req.query.item_id ??
            req.body?.Product_Id ??
            req.body?.productId ??
            req.body?.ProductId ??
            req.body?.product_id ??
            req.body?.Item_Id ??
            req.body?.itemId ??
            req.body?.item_id;

        const rawGodownId =
            req.query.Godown_Id ??
            req.query.godownId ??
            req.query.GodownId ??
            req.query.godown_id ??
            req.body?.Godown_Id ??
            req.body?.godownId ??
            req.body?.GodownId ??
            req.body?.godown_id;


        const rawBatch =
            req.query.Batch ??
            req.query.batch ??
            req.query.Batch_No ??
            req.query.batch_no ??
            req.body?.Batch ??
            req.body?.batch ??
            req.body?.Batch_No ??
            req.body?.batch_no;

        const normalizeDate = (val) => {
            if (!val) return ISOString();
            if (typeof val === "string") {
                const trimmed = val.trim();
                const match = trimmed.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
                if (match) {
                    const [, y, m, d] = match;
                    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
                }
            }
            return ISOString(val);
        };

        const fromDate = normalizeDate(rawFromDate);
        const toDate = normalizeDate(rawToDate);

        if (fromDate > toDate) {
            return noData(res);
        }

        const cleanProductId =
            rawProductId !== undefined && rawProductId !== null
                ? String(rawProductId).trim().replace(/^['"]+|['"]+$/g, "").trim()
                : "";

        if (!cleanProductId || isNaN(Number(cleanProductId))) {
            return noData(res);
        }

        const cleanGodownId =
            rawGodownId !== undefined && rawGodownId !== null
                ? String(rawGodownId).trim().replace(/^['"]+|['"]+$/g, "").trim()
                : "";

        if (!cleanGodownId || isNaN(Number(cleanGodownId))) {
            return noData(res);
        }

        const productId = Number(cleanProductId);

        const godownId = Number(cleanGodownId);

        let cleanBatch =
            rawBatch !== undefined && rawBatch !== null
                ? String(rawBatch)
                    .trim()
                    .replace(/^['"]+|['"]+$/g, "")
                    .replace(/^['"]+|['"]+$/g, "")
                    .trim()
                : "Primary Batch";

        if (!cleanBatch) {
            cleanBatch = "Primary Batch";
        }

        // Handle cases where users enter 'Primary_Batch' or similar with underscores
        if (cleanBatch.replace(/_/g, " ").toLowerCase() === "primary batch") {
            cleanBatch = "Primary Batch";
        }

        const request = new sql.Request();
        request.input("Fromdate", sql.NVarChar(200), fromDate);
        request.input("Todate", sql.NVarChar(200), toDate);
        request.input("Product_Id", sql.Int, productId);
        request.input("Godown_Id", sql.Int, godownId);
        request.input("Batch", sql.NVarChar(100), cleanBatch);

        let result = await request.query(
            `EXEC Transaction_Batch_Stock_Report_vw_By_Pro_Id_And_Godown_Id @Fromdate, @Todate, @Product_Id, @Godown_Id, @Batch`
        );

        let recordset = result.recordset ?? [];

        // If no records found and batch has underscores/spaces/plus, try fallback alternative formatting
        if (!recordset.length && (cleanBatch.includes("_") || cleanBatch.includes("+"))) {
            const alternativeBatch = cleanBatch.replace(/[_\+]/g, " ").trim();
            const retryRequest = new sql.Request();
            retryRequest.input("Fromdate", sql.NVarChar(200), fromDate);
            retryRequest.input("Todate", sql.NVarChar(200), toDate);
            retryRequest.input("Product_Id", sql.Int, productId);
            retryRequest.input("Godown_Id", sql.Int, godownId);
            retryRequest.input("Batch", sql.NVarChar(100), alternativeBatch);

            const retryResult = await retryRequest.query(
                `EXEC Transaction_Batch_Stock_Report_vw_By_Pro_Id_And_Godown_Id @Fromdate, @Todate, @Product_Id, @Godown_Id @Batch`
            );
            recordset = retryResult.recordset ?? [];
        }

        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PurchaseOrderTripItemDetails = async (req, res) => {
    try {
        const { Fromdate, Todate } = req.query;

        const fromDate = Fromdate ? ISOString(Fromdate) : ISOString();
        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Fromdate", fromDate)
            .input("Todate", toDate)
            .query(`EXEC Reporting_Online_Purchase_Order_Trip_Item_VW @Fromdate, @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const onlinePurchaseReportItemByOrderId = async (req, res) => {
    try {
        const rawPoId =
            req.query.Po_Id ??
            req.query.po_id ??
            req.query.PoId ??
            req.query.poid ??
            req.query.Order_Id ??
            req.query.order_id ??
            req.query.OrderId ??
            req.query.orderId ??
            req.query.id ??
            req.query.Id ??
            req.body?.Po_Id ??
            req.body?.po_id ??
            req.body?.PoId ??
            req.body?.poid ??
            req.body?.Order_Id ??
            req.body?.order_id ??
            req.body?.OrderId ??
            req.body?.orderId ??
            req.body?.id ??
            req.body?.Id ??
            req.params?.Po_Id ??
            req.params?.po_id ??
            req.params?.id;

        const cleanPoId =
            rawPoId !== undefined && rawPoId !== null
                ? String(rawPoId).trim().replace(/^["']+|["']+$/g, "").trim()
                : "";

        if (!cleanPoId || isNaN(Number(cleanPoId))) {
            return invalidInput(res, "Po_Id is required and must be a valid number");
        }

        const request = new sql.Request();
        request.input("Po_Id", sql.BigInt, cleanPoId);

        const result = await request.query(
            `EXEC Reporting_Online_Purchase_Item_VW_By_Order_Id @Po_Id`
        );

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};

export const PurchaseOrderPaymentReport = async (req, res) => {
    try {
        const { Todate } = req.query;

        const toDate = Todate ? ISOString(Todate) : ISOString();

        const result = await new sql.Request()
            .input("Todate", toDate)
            .query(`EXEC Purchase_Invoice_Paid_List @Todate`);

        const recordset = result.recordset ?? [];
        if (!recordset.length) return noData(res);

        dataFound(res, recordset);
    } catch (error) {
        servError(error, res);
    }
};






